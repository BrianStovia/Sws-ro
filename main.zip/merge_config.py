#!/usr/bin/env python3
import os
import sys

def extract_clients(filepath):
    vless, vmess, trojan = {}, {}, {}
    if not os.path.exists(filepath):
        return vless, vmess, trojan
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error reading backup config: {e}")
        return vless, vmess, trojan

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith("#& ") and not line.startswith("#&r "):
            if i + 1 < len(lines):
                vless[line] = [lines[i], lines[i+1]]
            i += 2
        elif line.startswith("### "):
            if i + 1 < len(lines):
                vmess[line] = [lines[i], lines[i+1]]
            i += 2
        elif line.startswith("#! "):
            if i + 1 < len(lines):
                trojan[line] = [lines[i], lines[i+1]]
            i += 2
        else:
            i += 1
    return vless, vmess, trojan

def main():
    bak_path = "/usr/local/etc/v2ray/config.json.bak"
    new_path = "/usr/local/etc/v2ray/config.json"
    
    if not os.path.exists(bak_path):
        print("No backup config found to merge.")
        return
        
    print("Merging existing accounts into the new configuration...")
    vless, vmess, trojan = extract_clients(bak_path)
    
    # Check if there is anything to merge
    total_clients = len(vless) + len(vmess) + len(trojan)
    if total_clients == 0:
        print("No accounts to merge.")
        return
        
    try:
        with open(new_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error reading new config: {e}")
        return

    out_lines = []
    for line in lines:
        out_lines.append(line)
        stripped = line.strip()
        if stripped.endswith("#vless"):
            for client_lines in vless.values():
                out_lines.extend(client_lines)
        elif stripped.endswith("#vmess"):
            for client_lines in vmess.values():
                out_lines.extend(client_lines)
        elif stripped.endswith("#trojan"):
            for client_lines in trojan.values():
                out_lines.extend(client_lines)
                
    try:
        with open(new_path, "w", encoding="utf-8") as f:
            f.writelines(out_lines)
        print(f"Successfully merged {total_clients} accounts back into configuration.")
    except Exception as e:
        print(f"Failed to write merged config: {e}")

if __name__ == "__main__":
    main()
