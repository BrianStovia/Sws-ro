import sys
import os
import re
import json
import urllib.request
import urllib.parse
import subprocess
import time

# Set encoding to utf-8
sys.stdout.reconfigure(encoding='utf-8')

# Paths
BOT_KEY_PATH = "/usr/local/etc/v2ray/bot.key"
CLIENT_ID_PATH = "/usr/local/etc/v2ray/client.id"
SELLERS_PATH = "/etc/telegram_sellers.json"

# Load bot details
def load_config():
    token = ""
    owner_id = ""
    if os.path.exists(BOT_KEY_PATH):
        with open(BOT_KEY_PATH, "r") as f:
            token = f.read().strip()
    if os.path.exists(CLIENT_ID_PATH):
        with open(CLIENT_ID_PATH, "r") as f:
            owner_id = f.read().strip()
    return token, owner_id

token, owner_id = load_config()

# Load sellers
def load_sellers():
    if os.path.exists(SELLERS_PATH):
        try:
            with open(SELLERS_PATH, "r") as f:
                return json.load(f)
        except Exception:
            return []
    return []

def save_sellers(sellers):
    with open(SELLERS_PATH, "w") as f:
        json.dump(sellers, f)

sellers = load_sellers()

def is_authorized(chat_id):
    chat_str = str(chat_id)
    return chat_str == str(owner_id) or chat_str in sellers

def clean_ansi(text):
    ansi_escape = re.compile(r'(?:\x1B|\033)(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

def send_message(chat_id, text, parse_mode="HTML", reply_markup=None):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    params = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": parse_mode
    }
    if reply_markup:
        params["reply_markup"] = reply_markup
    data = urllib.parse.urlencode(params).encode("utf-8")
    try:
        req = urllib.request.Request(url, data=data)
        urllib.request.urlopen(req, timeout=10)
    except Exception as e:
        print("Failed to send message:", e)

def answer_callback_query(callback_query_id):
    url = f"https://api.telegram.org/bot{token}/answerCallbackQuery"
    data = urllib.parse.urlencode({
        "callback_query_id": callback_query_id
    }).encode("utf-8")
    try:
        req = urllib.request.Request(url, data=data)
        urllib.request.urlopen(req, timeout=10)
    except Exception as e:
        print("Failed to answer callback query:", e)

def set_bot_commands():
    url = f"https://api.telegram.org/bot{token}/setMyCommands"
    commands = [
        {"command": "menu", "description": "Tampilkan Menu Utama"},
        {"command": "status", "description": "Cek Status VPS"},
        {"command": "listssh", "description": "Daftar Akun SSH"},
        {"command": "listnoobz", "description": "Daftar Akun NoobzVPN"},
        {"command": "help", "description": "Bantuan & Format Perintah"}
    ]
    data = json.dumps({"commands": commands}).encode("utf-8")
    try:
        req = urllib.request.Request(
            url, 
            data=data, 
            headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req, timeout=10)
        print("Bot commands menu registered successfully!")
    except Exception as e:
        print("Failed to set bot commands:", e)

def send_menu(chat_id):
    menu_text = (
        "🤖 <b>VPN SELLER BOT MENU</b> 🤖\n"
        "───────────────────────\n"
        "Silakan pilih opsi menu di bawah ini:"
    )
    keyboard = {
        "inline_keyboard": [
            [
                {"text": "➕ Create SSH", "callback_data": "/addssh"},
                {"text": "➕ Create Vmess", "callback_data": "/addvmess"}
            ],
            [
                {"text": "➕ Create Vless", "callback_data": "/addvless"},
                {"text": "➕ Create Trojan", "callback_data": "/addtrojan"}
            ],
            [
                {"text": "➕ Create Noobz", "callback_data": "/addnoobz"},
                {"text": "📊 VPS Status", "callback_data": "/status"}
            ],
            [
                {"text": "👥 List SSH", "callback_data": "/listssh"},
                {"text": "👥 List Noobz", "callback_data": "/listnoobz"}
            ]
        ]
    }
    send_message(chat_id, menu_text, reply_markup=json.dumps(keyboard))

def run_bash_cmd(cmd_str):
    try:
        res = subprocess.run(cmd_str, shell=True, capture_output=True, text=True, timeout=30)
        return clean_ansi(res.stdout + "\n" + res.stderr).strip()
    except subprocess.TimeoutExpired:
        return "Error: Command timed out!"
    except Exception as e:
        return f"Error: {e}"

user_states = {}

def handle_state_input(chat_id, text):
    state = user_states.get(chat_id)
    if not state:
        return
    
    action = state["action"]
    step = state["step"]
    
    if action == "addssh":
        if step == "username":
            username = text.strip()
            if not re.match(r'^[a-zA-Z0-9_]+$', username):
                send_message(chat_id, "❌ Username hanya boleh huruf, angka, dan underscore (_).\n\nMasukkan kembali Username:")
                return
            state["data"]["username"] = username
            state["step"] = "password"
            send_message(chat_id, "🔑 Masukkan Password:")
        elif step == "password":
            password = text.strip()
            if not password:
                send_message(chat_id, "❌ Password tidak boleh kosong.\n\nMasukkan kembali Password:")
                return
            state["data"]["password"] = password
            state["step"] = "days"
            send_message(chat_id, "📆 Masukkan Masa Aktif (Hari) (contoh: 30):")
        elif step == "days":
            days = text.strip()
            if not days.isdigit() or int(days) <= 0:
                send_message(chat_id, "❌ Masa aktif harus berupa angka positif.\n\nMasukkan kembali Masa Aktif (Hari):")
                return
            
            username = state["data"]["username"]
            password = state["data"]["password"]
            
            if chat_id in user_states:
                del user_states[chat_id]
                
            send_message(chat_id, f"⏳ Sedang membuat akun SSH untuk <code>{username}</code>...")
            cmd_str = f'printf "{username}\\n{password}\\n2\\n{days}\\n" | bash /usr/local/sbin/add-ssh'
            out = run_bash_cmd(cmd_str)
            send_message(chat_id, f"<pre>{out}</pre>")
            
    elif action in ["addvmess", "addvless", "addtrojan"]:
        if step == "username":
            username = text.strip()
            if not re.match(r'^[a-zA-Z0-9_]+$', username):
                send_message(chat_id, "❌ Username hanya boleh huruf, angka, dan underscore (_).\n\nMasukkan kembali Username:")
                return
            state["data"]["username"] = username
            if action == "addtrojan":
                state["step"] = "password"
                send_message(chat_id, "🔑 Masukkan Password untuk akun Trojan:\n(Ketik /default untuk menggunakan random UUID otomatis)")
            else:
                state["step"] = "uuid"
                send_message(chat_id, "🔑 Masukkan UUID untuk akun:\n(Ketik /default untuk menggunakan random UUID otomatis)")
        elif step in ["password", "uuid"]:
            val = text.strip()
            if val.lower() == "/default":
                val = ""
            elif len(val) < 5 or " " in val:
                send_message(chat_id, "❌ Input harus minimal 5 karakter dan tanpa spasi.\n\nMasukkan kembali (atau ketik /default):")
                return
            state["data"]["secret"] = val
            state["step"] = "days"
            send_message(chat_id, "📆 Masukkan Masa Aktif (Hari) (contoh: 30):")
        elif step == "days":
            days = text.strip()
            if not days.isdigit() or int(days) <= 0:
                send_message(chat_id, "❌ Masa aktif harus berupa angka positif.\n\nMasukkan kembali Masa Aktif (Hari):")
                return
            
            username = state["data"]["username"]
            secret = state["data"].get("secret", "")
            
            if chat_id in user_states:
                del user_states[chat_id]
                
            proto_name = "Vmess" if action == "addvmess" else ("Vless" if action == "addvless" else "Trojan")
            script_name = "add-vmess" if action == "addvmess" else ("add-vless" if action == "addvless" else "add-tr")
            
            send_message(chat_id, f"⏳ Sedang membuat akun {proto_name} untuk <code>{username}</code>...")
            cmd_str = f'printf "{username}\\n{days}\\n{secret}\\n" | bash /usr/local/sbin/{script_name}'
            out = run_bash_cmd(cmd_str)
            send_message(chat_id, f"<pre>{out}</pre>")
            
    elif action == "addnoobz":
        if step == "username":
            username = text.strip()
            if not re.match(r'^[a-zA-Z0-9_]+$', username):
                send_message(chat_id, "❌ Username hanya boleh huruf, angka, dan underscore (_).\n\nMasukkan kembali Username:")
                return
            state["data"]["username"] = username
            state["step"] = "device"
            send_message(chat_id, "💻 Masukkan Limit Device (contoh: 2):")
        elif step == "device":
            device = text.strip()
            if not device.isdigit() or int(device) <= 0:
                send_message(chat_id, "❌ Limit device harus berupa angka positif.\n\nMasukkan kembali Limit Device:")
                return
            state["data"]["device"] = device
            state["step"] = "bw"
            send_message(chat_id, "📊 Masukkan Bandwidth Limit (GB) (0 untuk no limit, contoh: 100):")
        elif step == "bw":
            bw = text.strip()
            if not bw.isdigit():
                send_message(chat_id, "❌ Bandwidth harus berupa angka.\n\nMasukkan kembali Bandwidth Limit (GB):")
                return
            state["data"]["bw"] = bw
            state["step"] = "days"
            send_message(chat_id, "📆 Masukkan Masa Aktif (Hari) (contoh: 30):")
        elif step == "days":
            days = text.strip()
            if not days.isdigit() or int(days) <= 0:
                send_message(chat_id, "❌ Masa aktif harus berupa angka positif.\n\nMasukkan kembali Masa Aktif (Hari):")
                return
            
            username = state["data"]["username"]
            device = state["data"]["device"]
            bw = state["data"]["bw"]
            
            if chat_id in user_states:
                del user_states[chat_id]
                
            send_message(chat_id, f"⏳ Sedang membuat akun NoobzVPN untuk <code>{username}</code>...")
            cmd_str = f'printf "{username}\\n{device}\\n{bw}\\n{days}\\n" | bash /usr/local/sbin/add-noobz'
            out = run_bash_cmd(cmd_str)
            send_message(chat_id, f"<pre>{out}</pre>")

def handle_command(chat_id, text):
    chat_str = str(chat_id)
    parts = text.split()
    if not parts:
        return
    
    cmd = parts[0].lower()
    
    if cmd == "/start" or cmd == "/menu":
        if not is_authorized(chat_id):
            send_message(chat_id, "❌ <b>Akses Ditolak:</b> ID Anda belum terdaftar sebagai Seller.")
            return
        send_menu(chat_id)
        return
        
    if cmd == "/help":
        if not is_authorized(chat_id):
            send_message(chat_id, "❌ <b>Akses Ditolak:</b> ID Anda belum terdaftar sebagai Seller.")
            return
        help_text = (
            "🤖 <b>VPN Seller Telegram Bot Help</b> 🤖\n"
            "───────────────────────\n"
            "<b>Daftar Perintah Pembuatan Akun:</b>\n"
            "• <code>/addssh &lt;user&gt; &lt;pass&gt; &lt;days&gt;</code>\n"
            "• <code>/addvmess &lt;user&gt; &lt;days&gt;</code>\n"
            "• <code>/addvless &lt;user&gt; &lt;days&gt;</code>\n"
            "• <code>/addtrojan &lt;user&gt; &lt;days&gt;</code>\n"
            "• <code>/addnoobz &lt;user&gt; &lt;limit_device&gt; &lt;bandwidth_gb&gt; &lt;days&gt;</code>\n"
            "───────────────────────\n"
            "<b>Daftar Perintah Manajemen & Status:</b>\n"
            "• <code>/status</code> - Cek status resource & service VPS\n"
            "• <code>/listssh</code> - Daftar akun SSH aktif\n"
            "• <code>/listnoobz</code> - Daftar akun NoobzVPN\n"
            "───────────────────────\n"
        )
        if chat_str == str(owner_id):
            help_text += (
                "<b>Perintah Owner Only:</b>\n"
                "• <code>/addseller &lt;chat_id&gt;</code> - Tambah seller baru\n"
                "• <code>/delseller &lt;chat_id&gt;</code> - Hapus seller\n"
                "• <code>/listsellers</code> - Daftar semua seller\n"
                "───────────────────────\n"
            )
        send_message(chat_id, help_text)
        return
        
    if not is_authorized(chat_id):
        send_message(chat_id, "❌ <b>Akses Ditolak:</b> ID Anda belum terdaftar sebagai Seller.")
        return
        
    if cmd == "/addssh":
        if len(parts) < 4:
            user_states[chat_id] = {"action": "addssh", "step": "username", "data": {}}
            send_message(chat_id, "➕ <b>Pembuatan Akun SSH</b>\n\nMasukkan Username:\n(Ketik /cancel untuk membatalkan)")
            return
        user, password, days = parts[1], parts[2], parts[3]
        send_message(chat_id, f"⏳ Sedang membuat akun SSH untuk <code>{user}</code>...")
        cmd_str = f'printf "{user}\\n{password}\\n2\\n{days}\\n" | bash /usr/local/sbin/add-ssh'
        out = run_bash_cmd(cmd_str)
        send_message(chat_id, f"<pre>{out}</pre>")
        
    elif cmd == "/addvmess":
        if len(parts) < 3:
            user_states[chat_id] = {"action": "addvmess", "step": "username", "data": {}}
            send_message(chat_id, "➕ <b>Pembuatan Akun Vmess</b>\n\nMasukkan Username:\n(Ketik /cancel untuk membatalkan)")
            return
        user, days = parts[1], parts[2]
        send_message(chat_id, f"⏳ Sedang membuat akun Vmess untuk <code>{user}</code>...")
        cmd_str = f'printf "{user}\\n{days}\\n\\n" | bash /usr/local/sbin/add-vmess'
        out = run_bash_cmd(cmd_str)
        send_message(chat_id, f"<pre>{out}</pre>")
        
    elif cmd == "/addvless":
        if len(parts) < 3:
            user_states[chat_id] = {"action": "addvless", "step": "username", "data": {}}
            send_message(chat_id, "➕ <b>Pembuatan Akun Vless</b>\n\nMasukkan Username:\n(Ketik /cancel untuk membatalkan)")
            return
        user, days = parts[1], parts[2]
        send_message(chat_id, f"⏳ Sedang membuat akun Vless untuk <code>{user}</code>...")
        cmd_str = f'printf "{user}\\n{days}\\n\\n" | bash /usr/local/sbin/add-vless'
        out = run_bash_cmd(cmd_str)
        send_message(chat_id, f"<pre>{out}</pre>")
        
    elif cmd == "/addtrojan":
        if len(parts) < 3:
            user_states[chat_id] = {"action": "addtrojan", "step": "username", "data": {}}
            send_message(chat_id, "➕ <b>Pembuatan Akun Trojan</b>\n\nMasukkan Username:\n(Ketik /cancel untuk membatalkan)")
            return
        user, days = parts[1], parts[2]
        send_message(chat_id, f"⏳ Sedang membuat akun Trojan untuk <code>{user}</code>...")
        cmd_str = f'printf "{user}\\n{days}\\n\\n" | bash /usr/local/sbin/add-tr'
        out = run_bash_cmd(cmd_str)
        send_message(chat_id, f"<pre>{out}</pre>")
        
    elif cmd == "/addnoobz":
        if len(parts) < 5:
            user_states[chat_id] = {"action": "addnoobz", "step": "username", "data": {}}
            send_message(chat_id, "➕ <b>Pembuatan Akun NoobzVPN</b>\n\nMasukkan Username:\n(Ketik /cancel untuk membatalkan)")
            return
        user, device, bw, days = parts[1], parts[2], parts[3], parts[4]
        send_message(chat_id, f"⏳ Sedang membuat akun NoobzVPN untuk <code>{user}</code>...")
        cmd_str = f'printf "{user}\\n{device}\\n{bw}\\n{days}\\n" | bash /usr/local/sbin/add-noobz'
        out = run_bash_cmd(cmd_str)
        send_message(chat_id, f"<pre>{out}</pre>")
        
    elif cmd == "/status":
        send_message(chat_id, "⏳ Mengambil status VPS...")
        def get_service_status(s):
            res = subprocess.run(f"systemctl is-active {s}", shell=True, capture_output=True, text=True)
            return "✅ ON" if res.stdout.strip() == "active" else "❌ OFF"
            
        v2ray_st = get_service_status("v2ray")
        nginx_st = get_service_status("nginx")
        sslh_st = get_service_status("sslh")
        noobz_st = get_service_status("noobzvpns")
        udp_st = get_service_status("udp-custom")
        proxy_st = get_service_status("proxy")
        
        mem_out = run_bash_cmd("free -h | awk 'NR==2 {print $3 \" / \" $2}'")
        cpu_out = run_bash_cmd("top -bn1 | grep 'Cpu(s)' | awk '{print $2}'") + "%"
        disk_out = run_bash_cmd("df -h / | awk 'NR==2 {print $3 \" / \" $2 \" ( \" $5 \" )\"}'")
        uptime_out = run_bash_cmd("uptime -p")
        
        status_text = (
            "⚙️ <b>VPS STATUS INFO</b> ⚙️\n"
            "───────────────────────\n"
            f"<b>CPU Usage  :</b> <code>{cpu_out}</code>\n"
            f"<b>Memory     :</b> <code>{mem_out}</code>\n"
            f"<b>Disk Space :</b> <code>{disk_out}</code>\n"
            f"<b>Uptime     :</b> <code>{uptime_out}</code>\n"
            "───────────────────────\n"
            "<b>SERVICES STATUS:</b>\n"
            f"• <b>V2Ray Core  :</b> {v2ray_st}\n"
            f"• <b>Nginx Server :</b> {nginx_st}\n"
            f"• <b>SSLH Proxy   :</b> {sslh_st}\n"
            f"• <b>NoobzVPN     :</b> {noobz_st}\n"
            f"• <b>UDP Custom   :</b> {udp_st}\n"
            f"• <b>Proxy SSHWS  :</b> {proxy_st}\n"
            "───────────────────────\n"
        )
        send_message(chat_id, status_text)
        
    elif cmd == "/listssh":
        send_message(chat_id, "⏳ Mengambil daftar akun SSH...")
        out = run_bash_cmd("awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd")
        send_message(chat_id, f"👥 <b>Daftar Akun SSH Aktif:</b>\n<pre>{out if out else 'Tidak ada akun'}</pre>")
        
    elif cmd == "/listnoobz":
        send_message(chat_id, "⏳ Mengambil daftar akun NoobzVPN...")
        out = run_bash_cmd("noobzvpns print-all | grep -E '^[0-9]+\\.'")
        send_message(chat_id, f"👥 <b>Daftar Akun NoobzVPN Aktif:</b>\n<pre>{out if out else 'Tidak ada akun'}</pre>")
        
    elif cmd == "/addseller":
        if chat_str != str(owner_id):
            send_message(chat_id, "❌ Perintah ini hanya khusus untuk Owner!")
            return
        if len(parts) < 2:
            send_message(chat_id, "💡 Format: <code>/addseller &lt;chat_id&gt;</code>")
            return
        new_seller = parts[1]
        sellers_list = load_sellers()
        if new_seller not in sellers_list:
            sellers_list.append(new_seller)
            save_sellers(sellers_list)
            send_message(chat_id, f"✅ Sukses menambahkan <code>{new_seller}</code> sebagai Seller baru.")
        else:
            send_message(chat_id, f"ℹ️ ID <code>{new_seller}</code> sudah terdaftar.")
            
    elif cmd == "/delseller":
        if chat_str != str(owner_id):
            send_message(chat_id, "❌ Perintah ini hanya khusus untuk Owner!")
            return
        if len(parts) < 2:
            send_message(chat_id, "💡 Format: <code>/delseller &lt;chat_id&gt;</code>")
            return
        del_seller = parts[1]
        sellers_list = load_sellers()
        if del_seller in sellers_list:
            sellers_list.remove(del_seller)
            save_sellers(sellers_list)
            send_message(chat_id, f"✅ Sukses menghapus <code>{del_seller}</code> dari daftar Seller.")
        else:
            send_message(chat_id, f"ℹ️ ID <code>{del_seller}</code> tidak ditemukan.")
            
    elif cmd == "/listsellers":
        if chat_str != str(owner_id):
            send_message(chat_id, "❌ Perintah ini hanya khusus untuk Owner!")
            return
        sellers_list = load_sellers()
        out = "\n".join([f"• <code>{s}</code>" for s in sellers_list])
        send_message(chat_id, f"👤 <b>Daftar Seller Terdaftar:</b>\n{out if out else 'Tidak ada seller lain'}")

# Main Polling Loop
def main_loop():
    print("Telegram Bot daemon started successfully!")
    set_bot_commands()
    offset = 0
    while True:
        try:
            url = f"https://api.telegram.org/bot{token}/getUpdates?offset={offset}&timeout=30"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=35) as response:
                res = json.loads(response.read().decode("utf-8"))
                if "result" in res:
                    for update in res["result"]:
                        offset = update["update_id"] + 1
                        if "message" in update and "text" in update["message"]:
                            msg = update["message"]
                            chat_id = msg["chat"]["id"]
                            text = msg["text"].strip()
                            
                            if not is_authorized(chat_id):
                                send_message(chat_id, "❌ <b>Akses Ditolak:</b> ID Anda belum terdaftar sebagai Seller.")
                                continue
                            
                            if text.startswith("/"):
                                if chat_id in user_states:
                                    del user_states[chat_id]
                                if text.lower() == "/cancel":
                                    send_message(chat_id, "❌ Pembuatan akun dibatalkan.")
                                    continue
                                handle_command(chat_id, text)
                            else:
                                if chat_id in user_states:
                                    handle_state_input(chat_id, text)
                                else:
                                    send_message(chat_id, "Gunakan tombol menu atau command /menu untuk memulai.")
                        elif "callback_query" in update:
                            cb = update["callback_query"]
                            chat_id = cb["message"]["chat"]["id"]
                            cb_data = cb["data"]
                            answer_callback_query(cb["id"])
                            if not is_authorized(chat_id):
                                send_message(chat_id, "❌ <b>Akses Ditolak:</b> ID Anda belum terdaftar sebagai Seller.")
                                continue
                            if chat_id in user_states:
                                del user_states[chat_id]
                            handle_command(chat_id, cb_data)
        except Exception as e:
            print("Loop error:", e)
            time.sleep(5)

if __name__ == "__main__":
    if not token:
        print("Error: Bot Token not found in /usr/local/etc/v2ray/bot.key")
        sys.exit(1)
    main_loop()
