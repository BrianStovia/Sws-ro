import sys
import json

def find_json_array(text, key):
    idx = text.find(key)
    if idx == -1:
        return None, -1, -1
    start_bracket = text.find('[', idx)
    if start_bracket == -1:
        return None, -1, -1
    count = 0
    for i in range(start_bracket, len(text)):
        char = text[i]
        if char == '[':
            count += 1
        elif char == ']':
            count -= 1
            if count == 0:
                end_bracket = i
                return text[start_bracket:end_bracket+1], start_bracket, end_bracket+1
    return None, -1, -1

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 toggle_warp.py [enable|disable]")
        sys.exit(1)
        
    action = sys.argv[1].lower()
    config_path = "/usr/local/etc/v2ray/config.json"
    
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            text = f.read()
    except Exception as e:
        print(f"Error reading config: {e}")
        sys.exit(1)
        
    # Process Outbounds
    outbounds_str, start_out, end_out = find_json_array(text, '"outbounds":')
    if not outbounds_str:
        print("Error: Could not find outbounds array in config.json")
        sys.exit(1)
        
    # Process Rules
    rules_str, start_rules, end_rules = find_json_array(text, '"rules":')
    if not rules_str:
        print("Error: Could not find routing rules array in config.json")
        sys.exit(1)
        
    try:
        outbounds = json.loads(outbounds_str)
        rules = json.loads(rules_str)
    except Exception as e:
        print(f"Error parsing JSON components: {e}")
        sys.exit(1)
        
    if action == "enable":
        # 1. Reconstruct outbounds (warp first, direct second, blocked third)
        warp_outbound = {
            "protocol": "socks",
            "settings": {
                "servers": [
                    {
                        "address": "127.0.0.1",
                        "port": 40000
                    }
                ]
            },
            "tag": "warp"
        }
        
        # Filter out existing warp/direct/blocked tags to rebuild without duplicates
        other_outbounds = [o for o in outbounds if o.get("tag") not in ("warp", "direct", "blocked")]
        
        direct_outbound = {
            "protocol": "freedom",
            "settings": {
                "domainStrategy": "UseIPv4"
            },
            "tag": "direct"
        }
        blocked_outbound = {
            "protocol": "blackhole",
            "settings": {},
            "tag": "blocked"
        }
        
        new_outbounds = [warp_outbound, direct_outbound, blocked_outbound] + other_outbounds
        
        # 2. Reconstruct rules (remove any existing UDP rules to avoid duplicates)
        new_rules = [r for r in rules if r.get("network") != "udp"]
        
        # Add the UDP rules at the top
        # Rule 1: Block UDP port 443 (QUIC) so browsers fall back to TCP (HTTP/2) over WARP
        # Rule 2: Route all other UDP traffic (games, VoIP, DNS) directly via VPS native connection
        udp_rules = [
            {
                "type": "field",
                "port": "443",
                "network": "udp",
                "outboundTag": "blocked"
            },
            {
                "type": "field",
                "network": "udp",
                "outboundTag": "direct"
            }
        ]
        new_rules = udp_rules + new_rules
        
    elif action == "disable":
        # 1. Reconstruct outbounds (remove warp, direct first, blocked second)
        other_outbounds = [o for o in outbounds if o.get("tag") not in ("warp", "direct", "blocked")]
        direct_outbound = {
            "protocol": "freedom",
            "settings": {
                "domainStrategy": "UseIPv4"
            },
            "tag": "direct"
        }
        blocked_outbound = {
            "protocol": "blackhole",
            "settings": {},
            "tag": "blocked"
        }
        new_outbounds = [direct_outbound, blocked_outbound] + other_outbounds
        
        # 2. Reconstruct rules (remove all UDP rules to clean up)
        new_rules = [r for r in rules if r.get("network") != "udp"]
        
    else:
        print(f"Unknown action: {action}")
        sys.exit(1)
        
    # Format the updated arrays nicely
    new_outbounds_str = json.dumps(new_outbounds, indent=2)
    new_rules_str = json.dumps(new_rules, indent=2)
    
    # Replace arrays in the original text, ensuring correct indices are used after modifications
    if start_out > start_rules:
        # outbounds is later in the file
        text = text[:start_out] + new_outbounds_str + text[end_out:]
        rules_str2, start_rules2, end_rules2 = find_json_array(text, '"rules":')
        text = text[:start_rules2] + new_rules_str + text[end_rules2:]
    else:
        # rules is later in the file
        text = text[:start_rules] + new_rules_str + text[end_rules:]
        outbounds_str2, start_out2, end_out2 = find_json_array(text, '"outbounds":')
        text = text[:start_out2] + new_outbounds_str + text[end_out2:]
        
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Successfully toggled WARP to: {action}")
    except Exception as e:
        print(f"Error writing config: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
